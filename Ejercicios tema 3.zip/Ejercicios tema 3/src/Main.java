
public class Main {
    public static void main(String[] args)
    {
        // Primera parte:
        // Crear una función con tres parámetros que sean números que se suman entre sí.
        // Llamar a la función en el main y darle valores.

        int suma = sumar(1, 2, 3);
        System.out.println("La suma es: " + suma);

        // Segunda parte:
        // Crear una clase coche.
        // Dentro de la clase coche, una variable numérica que almacene el número de puertas que tiene.
        // Una función que incremente el número de puertas que tiene el coche.
        // Crear un objeto miCoche en el main y añadirle una puerta.
        // Mostrar el número de puertas que tiene el objeto.

        Coche miCoche = new Coche();
        miCoche.anadirPuerta();
        System.out.println("Mi coche tiene " + miCoche.getNumPuertas() + " puerta.");


    }
    public static int sumar(int a, int b, int c)
    {
        int resultado = a + b + c;
        return resultado;
    }
    public static class Coche
    {
        private int numPuertas;

        public Coche()
        {
            numPuertas = 0;
        }

        public int getNumPuertas()
        {
            return numPuertas;
        }

        public void setNumPuertas(int numPuertas)
        {
            this.numPuertas = numPuertas;
        }

        public void anadirPuerta()
        {
            numPuertas++;
        }
    }

}


